// Isi dengan data proyek Supabase kamu (Project Settings > API).
// Anon key aman ditaruh di sini: yang membatasi akses adalah aturan RLS di schema.sql.
window.KAIZEN_CONFIG = {
  url: 'YOUR_SUPABASE_URL',
  anonKey: 'YOUR_SUPABASE_ANON_KEY'
};
